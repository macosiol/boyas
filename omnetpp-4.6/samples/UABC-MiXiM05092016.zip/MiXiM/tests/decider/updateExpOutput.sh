#!/bin/bash

./runTest.sh "update-exp-output"

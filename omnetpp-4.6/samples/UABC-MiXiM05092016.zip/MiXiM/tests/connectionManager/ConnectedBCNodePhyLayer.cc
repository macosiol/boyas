#include "ConnectedBCNodePhyLayer.h"

Define_Module( ConnectedBCNodePhyLayer);

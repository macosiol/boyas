#include "NotConnectedBCNodePhyLayer.h"

Define_Module( NotConnectedBCNodePhyLayer);

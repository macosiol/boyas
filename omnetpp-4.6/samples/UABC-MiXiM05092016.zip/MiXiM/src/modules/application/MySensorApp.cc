/***************************************************************************
 * file:        MySensorApp.h
 *
 * author:      Amre El-Hoiydi, Jerome Rousselot, Ramon Serna Oliver
 *
 * copyright:   (C) 2007-2008 CSEM
 *
 *              This program is free software; you can redistribute it
 *              and/or modify it under the terms of the GNU General Public
 *              License as published by the Free Software Foundation; either
 *              version 2 of the License, or (at your option) any later
 *              version.
 *              For further information see file COPYING
 *              in the top level directory
 ***************************************************************************
 * part of:     framework implementation developed by tkn
 * description: Generate periodic traffic addressed to a sink
 **************************************************************************/

#include "MySensorApp.h"

#include <sstream>

#include "BaseNetwLayer.h"
#include "AddressingInterface.h"
#include "NetwControlInfo.h"
#include "FindModule.h"
#include "SimpleAddress.h"
#include "BaseWorldUtility.h"
#include "ApplPkt_m.h"
#include "HelloPkt_m.h"

Define_Module(MySensorApp);

/**
 * First we have to initialize the module from which we derived ours,
 * in this case BasicModule.
 *
 * Then we will set a timer to indicate the first time we will send a
 * message
 *
 **/
void MySensorApp::initialize(int stage) {
    BaseLayer::initialize(stage);
	if (stage == 0) {
		BaseLayer::catPacketSignal.initialize();

		debugEV<< "in initialize() stage 0...";
		EV << "En función initialize() escenario 0. . ." << endl;
		debug = par("debug");
		stats = par("stats");
		trace = par("trace");
		nbPackets = par("nbPackets");
		trafficParam = par("trafficParam");
		initializationTime = par("initializationTime");
		esperaInicializacion = par("esperaInicializacion");
		broadcastPackets = par("broadcastPackets");
		headerLength = par("headerLength");
        TipoNodo = par("TipoNodo");  // Definimos el tipo de nodo que será
		// application configuration
		const char *traffic = par("trafficType");
		destAddr = LAddress::L3Type(par("destAddr").longValue());
		nbPacketsSent = 0;
		nbPacketsReceived = 0;
		firstPacketGeneration = -1;
		lastPacketReception = -2;
		banderaInicializacion = 0;
		listo = false;


		initializeDistribution(traffic);  //Se manda llamar a la función que define como será el tipo de tráfico

		delayTimer = new cMessage("appDelay", SEND_DATA_TIMER);

		// get pointer to the world module
		world = FindModule<BaseWorldUtility*>::findGlobalModule();

	} else if (stage == 1) {
		debugEV << "En initialize() Escenario 1...";
        EV << "En función initialize() escenario 1. . ." << endl;
		// Application address configuration: equals to host address

		cModule *const pHost = findHost();
		const cModule* netw  = FindModule<BaseNetwLayer*>::findSubModule(pHost);
		if(!netw) {
			netw = pHost->getSubmodule("netwl");
			if(!netw) {
				opp_error("No se pudo encontrar el módulo de la capa de Red. Esto significa que"
				        " el módulo de capa de red no está presente o "
				        "el módulo utilizado no es subclase de  "
						  "BaseNetworkLayer.");
			}
		}
		const AddressingInterface *const addrScheme = FindModule<AddressingInterface*>::findSubModule(pHost);
		if(addrScheme) {
			myAppAddr = addrScheme->myNetwAddr(netw);
		} else {
			myAppAddr = LAddress::L3Type( netw->getId() );
		}
		sentPackets = 0;


		if(nbPackets> 0)
			scheduleAt(simTime() +uniform(initializationTime, initializationTime + trafficParam), delayTimer);
		if (stats) {
			latenciesRaw.setName("rawLatencies");
			latenciesRaw.setUnit("s");
			latency.setName("latency");
		}
	}
}

cStdDev& MySensorApp::hostsLatency(const LAddress::L3Type& hostAddress)
{
	using std::pair;

	if(latencies.count(hostAddress) == 0) {
		std::ostringstream oss;
		oss << hostAddress;
		cStdDev aLatency(oss.str().c_str());
		latencies.insert(pair<LAddress::L3Type, cStdDev>(hostAddress, aLatency));
	}

	return latencies[hostAddress];
}

void MySensorApp::initializeDistribution(const char* traffic) {
	if (!strcmp(traffic, "periodic")) {
		trafficType = PERIODIC;
	} else if (!strcmp(traffic, "uniform")) {
		trafficType = UNIFORM;
	} else if (!strcmp(traffic, "exponential")) {
		trafficType = EXPONENTIAL;
	} else {
		trafficType = UNKNOWN;
		EV << "Error! Unknown traffic type: " << traffic << endl;
	}
}

/**
 * @brief Handling of messages arrived to destination
 **/
void MySensorApp::handleLowerMsg(cMessage * msg) {
	ApplPkt *m;
	m = static_cast<ApplPkt *> (msg);
	switch (TipoNodo) {
	case DISCONNECTED:
	    switch (msg->getKind()) {
	      case HELLO_RESPONSE:
	          EV << "El NODO[" << myAppAddr << "]  recibió paquete HELLO_RESPONSE del NODO[" << m->getSrcAddr() << "]" << endl;
	          EV << "Su valor de TipoNodo es " << m->getTipoNodo() << endl;
	          if (m->getTipoNodo()== SINK_NODE) {
	              banderaInicializacion = 1;
	             EV << "El NODO[" << myAppAddr <<"] era tipo " << TipoNodo <<" y se convirtió en nodo " << CLUSTER_HEAD << endl;
	                     TipoNodo = CLUSTER_HEAD;
	          }
	          else
	          {
	              if (m->getTipoNodo()== CLUSTER_HEAD) {
	                  EV << "El NODO[" << myAppAddr << "] era tipo " << TipoNodo <<" y se convirtió en nodo " << MEMBER_NODE << endl;
	                          TipoNodo = MEMBER_NODE;
	                          My_ClusterHead=m->getSrcAddr();
	                          banderaInicializacion = 1;
	                          Bandera_WACK=0;
	                      }
	          }
	          delete msg;
	          break;
	      default:
	          EV << "Error! NO EXISTEN MAS ACCIONES EN EL NODO DESCONECTADO: " << msg->getKind() << endl;
	          delete msg;
	          break;
	      }
	case SINK_NODE:
	          switch (msg->getKind()) {
	             case HELLO_MESSAGE:
	                 EV << "El NODO[" << myAppAddr <<"] recibió paquete HELLO desde el NODO[" << m->getSrcAddr() << "]" << endl;
	                 m->setName("HELLO_RESPONSE");
	                 m->setKind(HELLO_RESPONSE);
	                 m->setDestAddr(m->getSrcAddr());
	                 m->setSrcAddr(myAppAddr);
	                 m->setX_CoorGeo(X_CoorGeo);
	                 m->setY_CoorGeo(Y_CoorGeo);
	                 m->setZ_CoorGeo(Z_CoorGeo);
	                 m->setByteLength(headerLength);
	                 m->setTipoNodo(TipoNodo);
                     // set the control info to tell the network layer the layer 3 address
	                 // NetwControlInfo::setControlInfo(m, m->getDestAddr());
	                 EV << "El NODO[" << myAppAddr << "] es tipo " <<  TipoNodo << " y envía un paquete HELLO_RESPONSE hacia NODO[" << m->getDestAddr() << "]" << endl;
	                 sendDown(m);
	                 EV << "Paquete HELLO_RESPONSE enviado  !\n";
	                 break;
	             case DATA_MESSAGE:
	                    EV << "El NODO[" << myAppAddr << "] es tipo " <<  TipoNodo << " y envía un paquete de DATOS NODO[" << m->getDestAddr() << "]" << endl;
	                 delete msg;
	             break;
	             default:
	                 EV << "Error! se obtuvo un paquete con tipo desconocido: " << msg->getKind() << endl;
	                 delete msg;
	             break;
	             }
	    break;
	case MEMBER_NODE:
        switch (msg->getKind()) {
           case UPDT_REQUEST:
               EV << "El NODO[" << myAppAddr <<"] recibió paquete HELLO desde el NODO[" << m->getSrcAddr() << "]" << endl;
               if ((m->getTipoNodo()==CLUSTER_HEAD)&&(My_ClusterHead!=m->getSrcAddr()))
               {
                 TipoNodo=GATEWAY_NODE;
               }
                delete msg;
               break;
           case HELLO_RESPONSE:
               if (m->getTipoNodo()==SINK_NODE)
                {
                   m->setName("DELETE_REQUEST");
                   m->setKind(DELETE_REQUEST);
                   m->setDestAddr(My_ClusterHead);
                   m->setSrcAddr(myAppAddr);
                   m->setX_CoorGeo(X_CoorGeo);
                   m->setY_CoorGeo(Y_CoorGeo);
                   m->setZ_CoorGeo(Z_CoorGeo);
                   m->setByteLength(headerLength);
                   m->setTipoNodo(TipoNodo);
                   TipoNodo=CLUSTER_HEAD;
                   My_ClusterHead=0;
                   sendDown(m);
                   EV << "Paquete HELLO_RESPONSE enviado  !\n";
                }
               else
                  delete msg;
             break;
           }
        break;
	case CLUSTER_HEAD:
        switch (msg->getKind()) {
           case HELLO_MESSAGE:
               EV << "El NODO[" << myAppAddr <<"] recibió paquete HELLO desde el NODO[" << m->getSrcAddr() << "]" << endl;
               if (m->getTipoNodo()==DISCONNECTED)
               {
                 m->setName("HELLO_RESPONSE");
                 m->setKind(HELLO_RESPONSE);
                 m->setDestAddr(m->getSrcAddr());
                 m->setSrcAddr(myAppAddr);
                 m->setX_CoorGeo(X_CoorGeo);
                 m->setY_CoorGeo(Y_CoorGeo);
                 m->setZ_CoorGeo(Z_CoorGeo);
                 m->setByteLength(headerLength);
                 m->setTipoNodo(TipoNodo);
                // set the control info to tell the network layer the layer 3 address
                //     NetwControlInfo::setControlInfo(m, m->getDestAddr());
                EV << "El NODO[" << myAppAddr << "] es tipo " <<  TipoNodo << " y envía un paquete HELLO_RESPONSE hacia NODO[" << m->getDestAddr() << "]" << endl;
                sendDown(m);
                EV << "Paquete HELLO_RESPONSE enviado  !\n";
               }
               else
                 delete msg;
               break;
           case HELLO_RESPONSE:
                   EV << "El NODO[" << myAppAddr << "]  recibió paquete HELLO_RESPONSE del NODO[" << m->getSrcAddr() << "]" << endl;
                   if ((myAppAddr==m->getDestAddr())&&(m->getTipoNodo()==DISCONNECTED))
                    {
                      EV << "Su valor de TipoNodo es " << m->getTipoNodo() << endl;
                      EV << "El NODO[" << myAppAddr <<"] tipo " << TipoNodo <<" agrego un cliente " << endl;
                      if (Numero_Clientes<10)
                      {
                          Numero_Clientes++;
                          Tabla_Clientes(m->getSrcAddr(),1);
                      }
                      delete msg;
                    }
               break;
           case DELETE_REQUEST:
                   EV << "El NODO[" << myAppAddr << "]  recibió paquete DELETE_REQUEST del NODO[" << m->getSrcAddr() << "]" << endl;
                   if (myAppAddr==m->getDestAddr())
                    {
                      EV << "Su valor de TipoNodo es " << m->getTipoNodo() << endl;
                      EV << "El NODO[" << myAppAddr <<"] tipo " << TipoNodo <<" borro un cliente " << endl;
                      if (Numero_Clientes>0)
                      {
                        Numero_Clientes--; //LLAMAR A LA FUNCION ACTUALIZAR TABLA
                        Tabla_Clientes(m->getSrcAddr(),0);
                      }
                    }
               delete msg;
               break;
           case DATA_MESSAGE:
                     EV << "El NODO[" << myAppAddr << "] es tipo " <<  TipoNodo << " y envía un paquete de DATA_MESSAGE NODO[" << m->getDestAddr() << "]" << endl;
                     m->setName("DATA_MESSAGE");
                     m->setKind(DATA_MESSAGE);
                     m->setDestAddr(0);
                     m->setSrcAddr(myAppAddr);
                     m->setX_CoorGeo(X_CoorGeo);
                     m->setY_CoorGeo(Y_CoorGeo);
                     m->setZ_CoorGeo(Z_CoorGeo);
                     m->setByteLength(headerLength); //REVISAR POR LA LONGITUD DEL PAQUETE
                     m->setTipoNodo(TipoNodo);
                     sendDown(m);
                     EV << "Paquete DATOS enviado  !\n";
               break;
           default:
               EV << "Error! se obtuvo un paquete con tipo desconocido: " << msg->getKind() << endl;
               delete msg;
               break;
           }
        break;
	case GATEWAY_NODE:
        switch (msg->getKind()) {
           case HELLO_MESSAGE:
               if (m->getTipoNodo()==CLUSTER_HEAD)
               {
                   EV << "El NODO[" << myAppAddr << "]  recibió paquete HELLO_RESPONSE del NODO[" << m->getSrcAddr() << "]" << endl;
                   EV << "Su valor de TipoNodo es " << m->getTipoNodo() << endl;
                   EV << "El NODO[" << myAppAddr <<"] tipo " << TipoNodo <<" agrego un cliente " << endl;
                   if (Numero_Clientes<10)
                    {
                      Numero_Clientes++;
                      Tabla_Clientes(m->getSrcAddr(),1);
                    }
                   delete msg;
               }
               break;
           case HELLO_RESPONSE:
                if (m->getTipoNodo()==SINK_NODE)
                 {
                    m->setName("DELETE_REQUEST");
                    m->setKind(DELETE_REQUEST);
                    m->setDestAddr(My_ClusterHead);
                    m->setSrcAddr(myAppAddr);
                    m->setX_CoorGeo(X_CoorGeo);
                    m->setY_CoorGeo(Y_CoorGeo);
                    m->setZ_CoorGeo(Z_CoorGeo);
                    m->setByteLength(headerLength);
                    m->setTipoNodo(TipoNodo);
                    TipoNodo=CLUSTER_HEAD;
                    if (Numero_Clientes>0)
                      {
                        Tabla_Clientes(m->getDestAddr(),2);
                        Numero_Clientes=0;
                      }
                    My_ClusterHead=0;
                    sendDown(m);
                 }
                else
                  delete msg;
              break;
              default:
               EV << "NO HAY ACCIONE ASOCIADAS EN GATEWAY: " << msg->getKind() << endl;
               delete msg;
              break;
           }
        break;
    default:
        EV << "Error! TipoNodo no desconocido: " << TipoNodo << endl;
        delete msg;
        break;
    }
}

/**
 * @brief A timer with kind = SEND_DATA_TIMER indicates that a new
 * data has to be send (@ref sendData).
 *
 * There are no other timers implemented for this module.
 *
 * @sa sendData
 **/
void MySensorApp::handleSelfMsg(cMessage * msg) {
	switch (msg->getKind()) {
	case INIT_TIMER:
	    EV << "El NODO[" << myAppAddr << "] recibió un mensaje INIT_TIMER y la bandera es = " << banderaInicializacion << endl;
	    EV << "El NODO[" << myAppAddr << "] vuelve a enviar paquete HELLO \n";
	      if (banderaInicializacion == 0) {
	        sendHello();
	        delete msg;
	      }
	      else
	       {
	          EV << "El NODO[" << myAppAddr << "] Ya se forma parte de un cluster . . .\n";
	          delete msg;
	       }

	        break;
	case SEND_DATA_TIMER:
	    EV << "El NODO["<< myAppAddr <<"] Inicia la transmisión de mensajes desde el caso SEND_DATA_TIMER \n";
        if ((banderaInicializacion == 1)&&(Bandera_WACK==0)) {
            sendData(msg);
          delete msg;
        }
        else
         {

            My_ClusterHead=-1;
            myAppAddr=-1;
            TipoNodo=DISCONNECTED;
            banderaInicializacion =0;
            Bandera_WACK=0;
            EV << "El NODO[" << myAppAddr << "] desde el caso SEND_DATA_TIMER . . .\n";
            delete msg;
         }
		break;

	default:
		EV<< "Unkown selfmessage! -> delete, kind: " << msg->getKind() << endl;
		delete msg;
		break;
	}
}

void MySensorApp::handleLowerControl(cMessage * msg) {
	delete msg;
}

/**
  * @brief This function creates a new data message and sends it down to
  * the network layer
 **/
void MySensorApp::sendHello() {
    switch (TipoNodo) {
    case DISCONNECTED:
        ApplPkt *pkt = new ApplPkt("HELLO", HELLO_MESSAGE);
        pkt->setDestAddr(LAddress::L3BROADCAST);
        pkt->setSrcAddr(myAppAddr);
        pkt->setByteLength(headerLength);
        pkt->setTipoNodo(TipoNodo);
        // set the control info to tell the network layer the layer 3 address
        NetwControlInfo::setControlInfo(pkt, pkt->getDestAddr());
        EV << "El nodo[" << myAppAddr <<"] envía paquete HELLO hacia " << pkt->getDestAddr() << endl;
        sendDown(pkt);
        Espera = new cMessage("EsperaINIT", INIT_TIMER);
        scheduleAt(simTime() + esperaInicializacion, Espera);
        EV << "Paquete HELLO enviado  !\n";
        EV << "Esperando recibir respuesta de algún nodo...\n";
        break;
    }
}

void MySensorApp::sendData(cMessage * msg) {
    ApplPkt *m;
    m = static_cast<ApplPkt *> (msg);
    if ((m->getTipoNodo()==CLUSTER_HEAD)||(m->getTipoNodo()==GATEWAY_NODE)||(m->getTipoNodo()==GATEWAY_NODE))
       {
        ApplPkt *pkt = new ApplPkt("DATA_MESSAGE", HELLO_MESSAGE);
        pkt->setDestAddr(My_ClusterHead);;
        pkt->setSrcAddr(myAppAddr);
        pkt->setX_CoorGeo(X_CoorGeo);
        pkt->setY_CoorGeo(Y_CoorGeo);
        pkt->setZ_CoorGeo(Z_CoorGeo);
        pkt->setByteLength(headerLength);
        pkt->setTipoNodo(TipoNodo);
        // set the control info to tell the network layer the layer 3 address
        NetwControlInfo::setControlInfo(pkt, pkt->getDestAddr());
        EV << "El nodo[" << myAppAddr <<"] envía paquete DATOS_MESSAGE hacia " << pkt->getDestAddr() << endl;
        sendDown(pkt);
        EsperaDACK = new cMessage("Espera SEND_DATA_TIMER", SEND_DATA_TIMER);
        scheduleAt(simTime() + espera_ACK_datos, EsperaDACK);
        EV << "Paquete DATOS_MESSAGE enviado  !\n";
        EV << "Esperando recibir respuesta del nodo padre..." << pkt->getDestAddr() << endl;
        Bandera_WACK=1;
      }
}


void MySensorApp::Tabla_Clientes(LAddress::L3Type Src_Addr, int j) {
    for (int i=0;i<10;i++)
    {
        switch (j) {
        case 0:
          if (Src_Addr==tabla[i])
              tabla[i]=-1;
        break;
        case 1:
          if (-1==tabla[i])
           tabla[i]=Src_Addr;
        break;
        case 2:
            tabla[i]=-1;
        break;
      }
    }
}

void MySensorApp::finish() {
	using std::map;

	EV << "Soy el nodo " << myAppAddr << "y me quedé como nodo " << TipoNodo << endl;
	if (stats) {
		if (trace) {
			std::stringstream osToStr(std::stringstream::out);
			// output logs to scalar file
			for (map<LAddress::L3Type, cStdDev>::iterator it = latencies.begin(); it != latencies.end(); ++it) {
				cStdDev aLatency = it->second;

				osToStr.str(""); osToStr << "latencia" << it->first;
				recordScalar(osToStr.str().c_str(), aLatency.getMean(), "s");
				aLatency.record();
			}
		}
		recordScalar("activity duration", lastPacketReception
				- firstPacketGeneration, "s");
		recordScalar("firstPacketGeneration", firstPacketGeneration, "s");
		recordScalar("lastPacketReception", lastPacketReception, "s");
		recordScalar("nbPacketsSent", nbPacketsSent);
		recordScalar("nbPacketsReceived", nbPacketsReceived);
		latency.record();
	}
	cComponent::finish();
}

MySensorApp::~MySensorApp() {
	cancelAndDelete(delayTimer);
}

//
// Generated file, do not edit! Created by nedtool 4.6 from base/messages/HelloPkt.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#include <iostream>
#include <sstream>
#include "HelloPkt_m.h"

USING_NAMESPACE


// Another default rule (prevents compiler from choosing base class' doPacking())
template<typename T>
void doPacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doPacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}

template<typename T>
void doUnpacking(cCommBuffer *, T& t) {
    throw cRuntimeError("Parsim error: no doUnpacking() function for type %s or its base class (check .msg and _m.cc/h files!)",opp_typename(typeid(t)));
}




// Template rule for outputting std::vector<T> types
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');
    
    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

Register_Class(HelloPkt);

HelloPkt::HelloPkt(const char *name, int kind) : ::cPacket(name,kind)
{
    this->destAddr_var = LAddress::L3BROADCAST;
    this->srcAddr_var = LAddress::L3BROADCAST;
    this->X_CoorGeo_var = 0;
    this->Y_CoorGeo_var = 0;
    this->Z_CoorGeo_var = 0;
    this->Tipo_Nodo_var = 0;
    this->NodoID_var = 0;
}

HelloPkt::HelloPkt(const HelloPkt& other) : ::cPacket(other)
{
    copy(other);
}

HelloPkt::~HelloPkt()
{
}

HelloPkt& HelloPkt::operator=(const HelloPkt& other)
{
    if (this==&other) return *this;
    ::cPacket::operator=(other);
    copy(other);
    return *this;
}

void HelloPkt::copy(const HelloPkt& other)
{
    this->destAddr_var = other.destAddr_var;
    this->srcAddr_var = other.srcAddr_var;
    this->X_CoorGeo_var = other.X_CoorGeo_var;
    this->Y_CoorGeo_var = other.Y_CoorGeo_var;
    this->Z_CoorGeo_var = other.Z_CoorGeo_var;
    this->Tipo_Nodo_var = other.Tipo_Nodo_var;
    this->NodoID_var = other.NodoID_var;
}

void HelloPkt::parsimPack(cCommBuffer *b)
{
    ::cPacket::parsimPack(b);
    doPacking(b,this->destAddr_var);
    doPacking(b,this->srcAddr_var);
    doPacking(b,this->X_CoorGeo_var);
    doPacking(b,this->Y_CoorGeo_var);
    doPacking(b,this->Z_CoorGeo_var);
    doPacking(b,this->Tipo_Nodo_var);
    doPacking(b,this->NodoID_var);
}

void HelloPkt::parsimUnpack(cCommBuffer *b)
{
    ::cPacket::parsimUnpack(b);
    doUnpacking(b,this->destAddr_var);
    doUnpacking(b,this->srcAddr_var);
    doUnpacking(b,this->X_CoorGeo_var);
    doUnpacking(b,this->Y_CoorGeo_var);
    doUnpacking(b,this->Z_CoorGeo_var);
    doUnpacking(b,this->Tipo_Nodo_var);
    doUnpacking(b,this->NodoID_var);
}

LAddress::L3Type& HelloPkt::getDestAddr()
{
    return destAddr_var;
}

void HelloPkt::setDestAddr(const LAddress::L3Type& destAddr)
{
    this->destAddr_var = destAddr;
}

LAddress::L3Type& HelloPkt::getSrcAddr()
{
    return srcAddr_var;
}

void HelloPkt::setSrcAddr(const LAddress::L3Type& srcAddr)
{
    this->srcAddr_var = srcAddr;
}

float HelloPkt::getX_CoorGeo() const
{
    return X_CoorGeo_var;
}

void HelloPkt::setX_CoorGeo(float X_CoorGeo)
{
    this->X_CoorGeo_var = X_CoorGeo;
}

float HelloPkt::getY_CoorGeo() const
{
    return Y_CoorGeo_var;
}

void HelloPkt::setY_CoorGeo(float Y_CoorGeo)
{
    this->Y_CoorGeo_var = Y_CoorGeo;
}

float HelloPkt::getZ_CoorGeo() const
{
    return Z_CoorGeo_var;
}

void HelloPkt::setZ_CoorGeo(float Z_CoorGeo)
{
    this->Z_CoorGeo_var = Z_CoorGeo;
}

int HelloPkt::getTipo_Nodo() const
{
    return Tipo_Nodo_var;
}

void HelloPkt::setTipo_Nodo(int Tipo_Nodo)
{
    this->Tipo_Nodo_var = Tipo_Nodo;
}

int HelloPkt::getNodoID() const
{
    return NodoID_var;
}

void HelloPkt::setNodoID(int NodoID)
{
    this->NodoID_var = NodoID;
}

class HelloPktDescriptor : public cClassDescriptor
{
  public:
    HelloPktDescriptor();
    virtual ~HelloPktDescriptor();

    virtual bool doesSupport(cObject *obj) const;
    virtual const char *getProperty(const char *propertyname) const;
    virtual int getFieldCount(void *object) const;
    virtual const char *getFieldName(void *object, int field) const;
    virtual int findField(void *object, const char *fieldName) const;
    virtual unsigned int getFieldTypeFlags(void *object, int field) const;
    virtual const char *getFieldTypeString(void *object, int field) const;
    virtual const char *getFieldProperty(void *object, int field, const char *propertyname) const;
    virtual int getArraySize(void *object, int field) const;

    virtual std::string getFieldAsString(void *object, int field, int i) const;
    virtual bool setFieldAsString(void *object, int field, int i, const char *value) const;

    virtual const char *getFieldStructName(void *object, int field) const;
    virtual void *getFieldStructPointer(void *object, int field, int i) const;
};

Register_ClassDescriptor(HelloPktDescriptor);

HelloPktDescriptor::HelloPktDescriptor() : cClassDescriptor("HelloPkt", "cPacket")
{
}

HelloPktDescriptor::~HelloPktDescriptor()
{
}

bool HelloPktDescriptor::doesSupport(cObject *obj) const
{
    return dynamic_cast<HelloPkt *>(obj)!=NULL;
}

const char *HelloPktDescriptor::getProperty(const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : NULL;
}

int HelloPktDescriptor::getFieldCount(void *object) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 7+basedesc->getFieldCount(object) : 7;
}

unsigned int HelloPktDescriptor::getFieldTypeFlags(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeFlags(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISCOMPOUND,
        FD_ISCOMPOUND,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
        FD_ISEDITABLE,
    };
    return (field>=0 && field<7) ? fieldTypeFlags[field] : 0;
}

const char *HelloPktDescriptor::getFieldName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldNames[] = {
        "destAddr",
        "srcAddr",
        "X_CoorGeo",
        "Y_CoorGeo",
        "Z_CoorGeo",
        "Tipo_Nodo",
        "NodoID",
    };
    return (field>=0 && field<7) ? fieldNames[field] : NULL;
}

int HelloPktDescriptor::findField(void *object, const char *fieldName) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount(object) : 0;
    if (fieldName[0]=='d' && strcmp(fieldName, "destAddr")==0) return base+0;
    if (fieldName[0]=='s' && strcmp(fieldName, "srcAddr")==0) return base+1;
    if (fieldName[0]=='X' && strcmp(fieldName, "X_CoorGeo")==0) return base+2;
    if (fieldName[0]=='Y' && strcmp(fieldName, "Y_CoorGeo")==0) return base+3;
    if (fieldName[0]=='Z' && strcmp(fieldName, "Z_CoorGeo")==0) return base+4;
    if (fieldName[0]=='T' && strcmp(fieldName, "Tipo_Nodo")==0) return base+5;
    if (fieldName[0]=='N' && strcmp(fieldName, "NodoID")==0) return base+6;
    return basedesc ? basedesc->findField(object, fieldName) : -1;
}

const char *HelloPktDescriptor::getFieldTypeString(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldTypeString(object, field);
        field -= basedesc->getFieldCount(object);
    }
    static const char *fieldTypeStrings[] = {
        "LAddress::L3Type",
        "LAddress::L3Type",
        "float",
        "float",
        "float",
        "int",
        "int",
    };
    return (field>=0 && field<7) ? fieldTypeStrings[field] : NULL;
}

const char *HelloPktDescriptor::getFieldProperty(void *object, int field, const char *propertyname) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldProperty(object, field, propertyname);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        default: return NULL;
    }
}

int HelloPktDescriptor::getArraySize(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getArraySize(object, field);
        field -= basedesc->getFieldCount(object);
    }
    HelloPkt *pp = (HelloPkt *)object; (void)pp;
    switch (field) {
        default: return 0;
    }
}

std::string HelloPktDescriptor::getFieldAsString(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldAsString(object,field,i);
        field -= basedesc->getFieldCount(object);
    }
    HelloPkt *pp = (HelloPkt *)object; (void)pp;
    switch (field) {
        case 0: {std::stringstream out; out << pp->getDestAddr(); return out.str();}
        case 1: {std::stringstream out; out << pp->getSrcAddr(); return out.str();}
        case 2: return double2string(pp->getX_CoorGeo());
        case 3: return double2string(pp->getY_CoorGeo());
        case 4: return double2string(pp->getZ_CoorGeo());
        case 5: return long2string(pp->getTipo_Nodo());
        case 6: return long2string(pp->getNodoID());
        default: return "";
    }
}

bool HelloPktDescriptor::setFieldAsString(void *object, int field, int i, const char *value) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->setFieldAsString(object,field,i,value);
        field -= basedesc->getFieldCount(object);
    }
    HelloPkt *pp = (HelloPkt *)object; (void)pp;
    switch (field) {
        case 2: pp->setX_CoorGeo(string2double(value)); return true;
        case 3: pp->setY_CoorGeo(string2double(value)); return true;
        case 4: pp->setZ_CoorGeo(string2double(value)); return true;
        case 5: pp->setTipo_Nodo(string2long(value)); return true;
        case 6: pp->setNodoID(string2long(value)); return true;
        default: return false;
    }
}

const char *HelloPktDescriptor::getFieldStructName(void *object, int field) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructName(object, field);
        field -= basedesc->getFieldCount(object);
    }
    switch (field) {
        case 0: return opp_typename(typeid(LAddress::L3Type));
        case 1: return opp_typename(typeid(LAddress::L3Type));
        default: return NULL;
    };
}

void *HelloPktDescriptor::getFieldStructPointer(void *object, int field, int i) const
{
    cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount(object))
            return basedesc->getFieldStructPointer(object, field, i);
        field -= basedesc->getFieldCount(object);
    }
    HelloPkt *pp = (HelloPkt *)object; (void)pp;
    switch (field) {
        case 0: return (void *)(&pp->getDestAddr()); break;
        case 1: return (void *)(&pp->getSrcAddr()); break;
        default: return NULL;
    }
}



/*
 * MiXiMAirFrame.h
 *
 *  Created on: 07.03.2012
 *      Author: lindig
 */

#ifndef MIXIMAIRFRAME_H_
#define MIXIMAIRFRAME_H_

#include "messages/MiximAirFrame_m.h"

#endif /* MIXIMAIRFRAME_H_ */

/*
 * MiXiMMacPkt.h
 *
 *  Created on: 07.03.2012
 *      Author: lindig
 */

#ifndef MIXIMMACPKT_H_
#define MIXIMMACPKT_H_

#include "messages/MacPkt_m.h"

#endif /* MIXIMMACPKT_H_ */
